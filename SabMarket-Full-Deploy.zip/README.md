# SabMarket - सब मार्केट जोड़ो

एक मार्केट जो Amazon, Flipkart, Myntra, Ajio, Meesho को जोड़ता है।

## फीचर्स
- Unified search across all vendors
- तुरंत बुक करें - 2 सेकंड में booking
- Price compare
- Cart + Order history (localStorage)
- Fully offline, single HTML file

## Live Deploy - 1 Click

### Netlify
1. netlify.com/drop पर जाओ
2. इस पूरे folder को zip करके drag-drop करो
3. Live!

### Vercel
`vercel --prod`

### GitHub Pages
Repo में push करो, Settings > Pages enable करो

Made for India - Prices in ₹
