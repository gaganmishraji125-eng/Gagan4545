#!/bin/bash
pip3 install -r requirements.txt
python3 app.py &
sleep 6
python3 streamer.py
