@echo off
pip install -r requirements.txt
start cmd /k python app.py
timeout /t 6
start cmd /k python streamer.py
