import feedparser, hashlib, time, requests
from flask import Flask, render_template
from apscheduler.schedulers.background import BackgroundScheduler
from googletrans import Translator
from telegram import Bot
import threading, json
from config import *

app = Flask(__name__, static_folder='static')
translator = Translator()
seen = set()
latest_news = []

WORLD_FEEDS = [
    "http://feeds.reuters.com/reuters/worldNews",
    "http://feeds.bbci.co.uk/news/world/rss.xml",
    "https://rss.nytimes.com/services/xml/rss/nyt/World.xml",
    "http://rss.cnn.com/rss/edition_world.rss",
    "https://www.aljazeera.com/xml/rss/all.xml",
    "https://feeds.feedburner.com/ndtvnews-world-news",
    "https://www.theguardian.com/world/rss"
]

def get_amp(url):
    if "YOUR_GOOGLE" in AMP_API_KEY: return url
    try:
        api = f"https://acceleratedmobilepageurl.googleapis.com/v1/ampUrls:batchGet?key={AMP_API_KEY}"
        r = requests.post(api, json={"urls":[url]}, timeout=5)
        return r.json()['ampUrls'][0]['ampUrl']
    except: return url

def translate_hi(t):
    try: return translator.translate(t, src='en', dest='hi').text
    except: return t

def post_telegram(title, link, src):
    if "YOUR" in TELEGRAM_BOT_TOKEN: return
    try:
        Bot(TELEGRAM_BOT_TOKEN).send_message(
            chat_id=TELEGRAM_CHAT_ID,
            text=f"🚨 <b>{title}</b>\n\n{src} | {CHANNEL_NAME}\n<a href='{link}'>तेज़ AMP लिंक</a>",
            parse_mode='HTML', disable_web_page_preview=False)
    except: pass

def check():
    global latest_news
    for url in WORLD_FEEDS:
        f = feedparser.parse(url)
        for e in f.entries[:5]:
            uid = hashlib.md5((e.title+e.link).encode()).hexdigest()
            if uid in seen: continue
            seen.add(uid)
            hi = translate_hi(e.title)
            amp = get_amp(e.link)
            item = {"time": time.strftime("%H:%M:%S"), "title_hi": hi, "title_en": e.title, "link": amp, "source": f.feed.title}
            latest_news.insert(0,item); latest_news=latest_news[:50]
            with open("latest.json","w",encoding="utf-8") as jf: json.dump(item,jf,ensure_ascii=False)
            threading.Thread(target=post_telegram, args=(hi,amp,f.feed.title)).start()
            print("NEW:",hi,"->",amp); return

@app.route("/")
def home(): return render_template("index.html", news=latest_news, channel=CHANNEL_NAME)

sched = BackgroundScheduler(); sched.add_job(check,'interval',seconds=POLL_SECONDS); sched.start(); check()
if __name__ == "__main__": app.run(host="0.0.0.0",port=5000)
