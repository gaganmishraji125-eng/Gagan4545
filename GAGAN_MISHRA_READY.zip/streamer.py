import time, json, os, subprocess
from gtts import gTTS
from PIL import Image, ImageDraw, ImageFont
from config import YOUTUBE_RTMP, CHANNEL_NAME

LOGO = Image.open("static/logo.png").convert("RGBA")

def make_frame(text, source, t):
    base = Image.new('RGB', (1920,1080), (8,8,12))
    draw = ImageDraw.Draw(base)
    # top bar
    draw.rectangle([(0,0),(1920,160)], fill=(190,0,0))
    base.paste(LOGO, (40,20), LOGO)
    try:
        f1 = ImageFont.truetype("arialbd.ttf", 100)
        f2 = ImageFont.truetype("arial.ttf", 50)
        f3 = ImageFont.truetype("arialbd.ttf", 72)
    except: f1=f2=f3=None
    draw.text((360,45), CHANNEL_NAME, fill="white", font=f3)
    draw.text((80,260), "🚨 ब्रेकिंग न्यूज़", fill=(255,90,90), font=f2)
    # wrap
    words=text.split(); lines=[]; cur=""
    for w in words:
        if len(cur+w)<38: cur+=w+" "
        else: lines.append(cur); cur=w+" "
    lines.append(cur)
    y=360
    for ln in lines[:3]:
        draw.text((80,y), ln.strip(), fill="white", font=f1); y+=130
    draw.text((80,980), f"{source} | {t} IST | LIVE", fill=(170,170,170), font=f2)
    base.save("/tmp/frame.png")

def stream(item):
    make_frame(item['title_hi'], item['source'], item['time'])
    gTTS(item['title_hi'], lang='hi').save("/tmp/audio.mp3")
    cmd = ["ffmpeg","-y","-loop","1","-i","/tmp/frame.png","-i","/tmp/audio.mp3",
           "-c:v","libx264","-preset","veryfast","-tune","stillimage","-b:v","3000k",
           "-c:a","aac","-b:a","160k","-shortest","-pix_fmt","yuv420p","-f","flv", YOUTUBE_RTMP]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

print("WORLD NEWS RUDRA - Live Ready")
last=""
while True:
    if os.path.exists("latest.json"):
        with open("latest.json") as f: data=json.load(f)
        js=json.dumps(data)
        if js!=last: last=js; stream(data)
    time.sleep(3)
