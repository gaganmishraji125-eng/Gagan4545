#!/usr/bin/env python3
"""
Amazon India Affiliate Link Generator - Automated System
Amazon Associates Affiliate ID: rudrakchstore-21
"""

import json
import time
from datetime import datetime
from urllib.parse import urlencode, urlparse, parse_qs

class AffiliateSystem:
    def __init__(self, affiliate_id="rudrakchstore-21"):
        self.affiliate_id = affiliate_id
        self.stats = {
            "total_links": 0,
            "total_products": 0,
            "categories_processed": 0,
            "last_updated": None
        }
        
    def generate_amazon_link(self, product_url, custom_tag=None):
        """
        Generate Amazon India affiliate link
        Format: https://www.amazon.in/dp/PRODUCT_ID?tag=YOUR_TAG
        """
        tag = custom_tag or self.affiliate_id
        
        # Parse the URL
        parsed = urlparse(product_url)
        
        # Extract product ID (ASIN)
        if '/dp/' in product_url:
            product_id = product_url.split('/dp/')[1].split('/')[0].split('?')[0]
        elif '/gp/product/' in product_url:
            product_id = product_url.split('/gp/product/')[1].split('/')[0].split('?')[0]
        else:
            product_id = None
            
        if product_id:
            # Clean format
            affiliate_link = f"https://www.amazon.in/dp/{product_id}?tag={tag}"
        else:
            # Add tag to existing URL
            params = parse_qs(parsed.query)
            params['tag'] = [tag]
            affiliate_link = f"{parsed.scheme}://{parsed.netloc}{parsed.path}?{urlencode(params, doseq=True)}"
        
        self.stats["total_links"] += 1
        return affiliate_link
    
    def generate_flipkart_link(self, product_url, affiliate_id=None):
        """
        Generate Flipkart affiliate link
        Format: https://www.flipkart.com/product?affid=YOUR_ID
        """
        affid = affiliate_id or self.affiliate_id
        parsed = urlparse(product_url)
        params = parse_qs(parsed.query)
        params['affid'] = [affid]
        
        affiliate_link = f"{parsed.scheme}://{parsed.netloc}{parsed.path}?{urlencode(params, doseq=True)}"
        self.stats["total_links"] += 1
        return affiliate_link
    
    def create_product_catalog(self):
        """
        Create a catalog of popular Indian products with affiliate links
        """
        products = {
            "electronics": [
                {
                    "name": "Redmi Note 13 Pro 5G",
                    "amazon_url": "https://www.amazon.in/dp/B0CX3X3X3X",
                    "category": "Mobile Phones",
                    "price_range": "20000-25000",
                    "commission_rate": "3-5%"
                },
                {
                    "name": "Samsung Galaxy Buds2 Pro",
                    "amazon_url": "https://www.amazon.in/dp/B0B5B5B5B5",
                    "category": "Audio",
                    "price_range": "10000-15000",
                    "commission_rate": "5-8%"
                },
                {
                    "name": "Fire TV Stick 4K",
                    "amazon_url": "https://www.amazon.in/dp/B08XVYZ8F5",
                    "category": "Streaming Devices",
                    "price_range": "3000-5000",
                    "commission_rate": "7-10%"
                }
            ],
            "fashion": [
                {
                    "name": "Levi's Men's Jeans",
                    "amazon_url": "https://www.amazon.in/dp/B01ABCDEFG",
                    "category": "Clothing",
                    "price_range": "1500-2500",
                    "commission_rate": "10-15%"
                }
            ],
            "home_kitchen": [
                {
                    "name": "Prestige Induction Cooktop",
                    "amazon_url": "https://www.amazon.in/dp/B07HHHHHHH",
                    "category": "Kitchen Appliances",
                    "price_range": "2000-3000",
                    "commission_rate": "5-8%"
                }
            ],
            "books": [
                {
                    "name": "Atomic Habits - James Clear",
                    "amazon_url": "https://www.amazon.in/dp/B07RFSSYBH",
                    "category": "Self-Help",
                    "price_range": "300-500",
                    "commission_rate": "10-12%"
                }
            ]
        }
        
        return products
    
    def generate_all_affiliate_links(self):
        """
        Generate affiliate links for all products in catalog
        """
        catalog = self.create_product_catalog()
        affiliate_data = {}
        
        print(f"\n{'='*80}")
        print(f"🚀 AFFILIATE LINK GENERATOR - Amazon Associates")
        print(f"📌 Affiliate ID: {self.affiliate_id}")
        print(f"{'='*80}\n")
        
        for category, products in catalog.items():
            print(f"\n📦 Category: {category.upper()}")
            print("-" * 80)
            
            affiliate_data[category] = []
            
            for product in products:
                affiliate_link = self.generate_amazon_link(product["amazon_url"])
                
                product_data = {
                    "name": product["name"],
                    "category": product["category"],
                    "original_url": product["amazon_url"],
                    "affiliate_link": affiliate_link,
                    "price_range": product["price_range"],
                    "commission_rate": product["commission_rate"]
                }
                
                affiliate_data[category].append(product_data)
                self.stats["total_products"] += 1
                
                print(f"\n✅ Product: {product['name']}")
                print(f"   Price: ₹{product['price_range']}")
                print(f"   Commission: {product['commission_rate']}")
                print(f"   🔗 Affiliate Link: {affiliate_link}")
            
            self.stats["categories_processed"] += 1
        
        self.stats["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        return affiliate_data
    
    def export_to_file(self, data, filename="affiliate_links.json"):
        """
        Export affiliate links to JSON file
        """
        export_data = {
            "affiliate_id": self.affiliate_id,
            "generated_at": self.stats["last_updated"],
            "statistics": self.stats,
            "products": data
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
        
        print(f"\n\n💾 Exported to: {filename}")
        return filename
    
    def export_to_text(self, data, filename="affiliate_links.txt"):
        """
        Export affiliate links to readable text file
        """
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("="*80 + "\n")
            f.write(f"AMAZON INDIA AFFILIATE LINKS\n")
            f.write(f"Affiliate ID: {self.affiliate_id}\n")
            f.write(f"Generated: {self.stats['last_updated']}\n")
            f.write("="*80 + "\n\n")
            
            for category, products in data.items():
                f.write(f"\n{'='*80}\n")
                f.write(f"CATEGORY: {category.upper()}\n")
                f.write(f"{'='*80}\n\n")
                
                for idx, product in enumerate(products, 1):
                    f.write(f"{idx}. {product['name']}\n")
                    f.write(f"   Price Range: ₹{product['price_range']}\n")
                    f.write(f"   Commission: {product['commission_rate']}\n")
                    f.write(f"   Affiliate Link: {product['affiliate_link']}\n\n")
                    f.write(f"   {'-'*76}\n\n")
        
        print(f"💾 Exported to: {filename}")
        return filename
    
    def print_statistics(self):
        """
        Print generation statistics
        """
        print(f"\n\n{'='*80}")
        print(f"📊 GENERATION STATISTICS")
        print(f"{'='*80}")
        print(f"✅ Total Products Processed: {self.stats['total_products']}")
        print(f"🔗 Total Affiliate Links Generated: {self.stats['total_links']}")
        print(f"📦 Categories Processed: {self.stats['categories_processed']}")
        print(f"⏰ Last Updated: {self.stats['last_updated']}")
        print(f"{'='*80}\n")


def create_whatsapp_message(product_name, affiliate_link, price):
    """
    Create WhatsApp-ready message for sharing
    """
    message = f"""
🛍️ *{product_name}*

💰 Price: ₹{price}
🔥 Special Deal Available!

👉 Buy Now: {affiliate_link}

✨ Limited Time Offer!
    """.strip()
    
    return message


def create_instagram_caption(product_name, affiliate_link):
    """
    Create Instagram-ready caption
    """
    caption = f"""
🌟 Product of the Day: {product_name}

💎 Premium Quality
🚚 Fast Delivery
💯 Best Price Guaranteed

🔗 Link in Bio or DM for Direct Link!

#amazon #shopping #deals #india #onlineshopping #affiliate #product
    """.strip()
    
    return caption


def main():
    """
    Main execution function
    """
    print("\n" + "="*80)
    print("🚀 AUTOMATED AFFILIATE LINK GENERATOR")
    print("="*80 + "\n")
    
    # Initialize system with your affiliate ID
    system = AffiliateSystem(affiliate_id="rudrakchstore-21")
    
    # Generate all links
    affiliate_data = system.generate_all_affiliate_links()
    
    # Print statistics
    system.print_statistics()
    
    # Export to files
    system.export_to_file(affiliate_data, "affiliate_links.json")
    system.export_to_text(affiliate_data, "affiliate_links.txt")
    
    # Generate sample marketing messages
    print("\n" + "="*80)
    print("📱 SAMPLE MARKETING MESSAGES")
    print("="*80 + "\n")
    
    sample_product = affiliate_data["electronics"][0]
    
    print("📲 WhatsApp Message:")
    print("-" * 80)
    print(create_whatsapp_message(
        sample_product["name"], 
        sample_product["affiliate_link"],
        sample_product["price_range"]
    ))
    
    print("\n\n📸 Instagram Caption:")
    print("-" * 80)
    print(create_instagram_caption(
        sample_product["name"],
        sample_product["affiliate_link"]
    ))
    
    print("\n\n" + "="*80)
    print("✅ PROCESS COMPLETED SUCCESSFULLY!")
    print("="*80 + "\n")


if __name__ == "__main__":
    main()
