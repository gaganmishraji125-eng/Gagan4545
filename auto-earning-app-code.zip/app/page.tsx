"use client"

import { useState } from "react"
import {
  BookOpen,
  Smartphone,
  Video,
  FileText,
  Music,
  Palette,
  Code,
  GraduationCap,
  TrendingUp,
  IndianRupee,
  Calculator,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Filter,
  Search,
  ChevronRight,
  Wallet,
  Target,
  Zap,
  Star,
  ExternalLink,
} from "lucide-react"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from "recharts"

// Types
interface Platform {
  id: string
  name: string
  category: string
  icon: React.ReactNode
  description: string
  potentialEarning: string
  minEarning: number
  maxEarning: number
  difficulty: "Easy" | "Medium" | "Hard"
  timeRequired: string
  link: string
  features: string[]
  indianFriendly: boolean
}

interface Earning {
  id: string
  platformId: string
  amount: number
  date: string
  type: "sale" | "royalty" | "subscription"
}

// Data
const platforms: Platform[] = [
  {
    id: "amazon-kdp",
    name: "Amazon KDP",
    category: "E-Books",
    icon: <BookOpen className="h-5 w-5" />,
    description: "Publish and sell e-books on Amazon Kindle store",
    potentialEarning: "5,000 - 2,00,000/month",
    minEarning: 5000,
    maxEarning: 200000,
    difficulty: "Medium",
    timeRequired: "2-4 weeks per book",
    link: "https://kdp.amazon.com",
    features: ["70% royalty", "Global reach", "Print on demand"],
    indianFriendly: true,
  },
  {
    id: "google-play-books",
    name: "Google Play Books",
    category: "E-Books",
    icon: <BookOpen className="h-5 w-5" />,
    description: "Sell e-books through Google Play Store",
    potentialEarning: "3,000 - 1,00,000/month",
    minEarning: 3000,
    maxEarning: 100000,
    difficulty: "Medium",
    timeRequired: "2-3 weeks per book",
    link: "https://play.google.com/books/publish",
    features: ["52% royalty", "Android users", "Easy upload"],
    indianFriendly: true,
  },
  {
    id: "udemy",
    name: "Udemy",
    category: "Online Courses",
    icon: <GraduationCap className="h-5 w-5" />,
    description: "Create and sell online courses globally",
    potentialEarning: "10,000 - 5,00,000/month",
    minEarning: 10000,
    maxEarning: 500000,
    difficulty: "Hard",
    timeRequired: "1-3 months per course",
    link: "https://www.udemy.com/teaching",
    features: ["97% with own promo", "Huge audience", "Marketing support"],
    indianFriendly: true,
  },
  {
    id: "skillshare",
    name: "Skillshare",
    category: "Online Courses",
    icon: <GraduationCap className="h-5 w-5" />,
    description: "Share creative skills and earn royalties",
    potentialEarning: "5,000 - 2,00,000/month",
    minEarning: 5000,
    maxEarning: 200000,
    difficulty: "Medium",
    timeRequired: "2-4 weeks per class",
    link: "https://www.skillshare.com/teach",
    features: ["Watch-time royalties", "Creative focus", "Community"],
    indianFriendly: true,
  },
  {
    id: "unacademy",
    name: "Unacademy",
    category: "Online Courses",
    icon: <GraduationCap className="h-5 w-5" />,
    description: "Teach competitive exams to Indian students",
    potentialEarning: "20,000 - 10,00,000/month",
    minEarning: 20000,
    maxEarning: 1000000,
    difficulty: "Hard",
    timeRequired: "Ongoing commitment",
    link: "https://unacademy.com/educator",
    features: ["Indian audience", "Live classes", "High earning"],
    indianFriendly: true,
  },
  {
    id: "google-play-apps",
    name: "Google Play Store",
    category: "Mobile Apps",
    icon: <Smartphone className="h-5 w-5" />,
    description: "Publish Android apps and earn from ads/purchases",
    potentialEarning: "5,000 - 50,00,000/month",
    minEarning: 5000,
    maxEarning: 5000000,
    difficulty: "Hard",
    timeRequired: "1-6 months per app",
    link: "https://play.google.com/console",
    features: ["AdMob integration", "In-app purchases", "Subscriptions"],
    indianFriendly: true,
  },
  {
    id: "apple-app-store",
    name: "Apple App Store",
    category: "Mobile Apps",
    icon: <Smartphone className="h-5 w-5" />,
    description: "Publish iOS apps for Apple devices",
    potentialEarning: "10,000 - 1,00,00,000/month",
    minEarning: 10000,
    maxEarning: 10000000,
    difficulty: "Hard",
    timeRequired: "2-8 months per app",
    link: "https://developer.apple.com",
    features: ["Premium users", "70-85% revenue", "Global reach"],
    indianFriendly: true,
  },
  {
    id: "youtube",
    name: "YouTube",
    category: "Video Content",
    icon: <Video className="h-5 w-5" />,
    description: "Create videos and earn from ads and memberships",
    potentialEarning: "5,000 - 50,00,000/month",
    minEarning: 5000,
    maxEarning: 5000000,
    difficulty: "Medium",
    timeRequired: "Ongoing",
    link: "https://www.youtube.com/creators",
    features: ["AdSense", "Memberships", "Super Chat"],
    indianFriendly: true,
  },
  {
    id: "shutterstock",
    name: "Shutterstock",
    category: "Stock Assets",
    icon: <Palette className="h-5 w-5" />,
    description: "Sell photos, videos, and music",
    potentialEarning: "2,000 - 1,00,000/month",
    minEarning: 2000,
    maxEarning: 100000,
    difficulty: "Easy",
    timeRequired: "Ongoing uploads",
    link: "https://submit.shutterstock.com",
    features: ["15-40% royalty", "Multiple asset types", "Passive income"],
    indianFriendly: true,
  },
  {
    id: "envato",
    name: "Envato Market",
    category: "Digital Templates",
    icon: <FileText className="h-5 w-5" />,
    description: "Sell themes, templates, graphics, and code",
    potentialEarning: "10,000 - 5,00,000/month",
    minEarning: 10000,
    maxEarning: 500000,
    difficulty: "Hard",
    timeRequired: "2-8 weeks per item",
    link: "https://author.envato.com",
    features: ["37.5-87.5% royalty", "Multiple categories", "Large market"],
    indianFriendly: true,
  },
  {
    id: "gumroad",
    name: "Gumroad",
    category: "Digital Products",
    icon: <Zap className="h-5 w-5" />,
    description: "Sell any digital product directly to audience",
    potentialEarning: "5,000 - 10,00,000/month",
    minEarning: 5000,
    maxEarning: 1000000,
    difficulty: "Medium",
    timeRequired: "Varies by product",
    link: "https://gumroad.com",
    features: ["90% after fees", "Direct sales", "Memberships"],
    indianFriendly: true,
  },
  {
    id: "canva",
    name: "Canva Creators",
    category: "Design Templates",
    icon: <Palette className="h-5 w-5" />,
    description: "Create and sell templates on Canva",
    potentialEarning: "5,000 - 2,00,000/month",
    minEarning: 5000,
    maxEarning: 200000,
    difficulty: "Easy",
    timeRequired: "Few hours per template",
    link: "https://www.canva.com/creators",
    features: ["35% royalty", "Easy to create", "Huge user base"],
    indianFriendly: true,
  },
  {
    id: "audiojungle",
    name: "AudioJungle",
    category: "Audio/Music",
    icon: <Music className="h-5 w-5" />,
    description: "Sell royalty-free music and sound effects",
    potentialEarning: "5,000 - 3,00,000/month",
    minEarning: 5000,
    maxEarning: 300000,
    difficulty: "Medium",
    timeRequired: "1-5 days per track",
    link: "https://audiojungle.net/become-an-author",
    features: ["Royalty free", "Video creators buy", "Passive income"],
    indianFriendly: true,
  },
  {
    id: "codecanyon",
    name: "CodeCanyon",
    category: "Code/Scripts",
    icon: <Code className="h-5 w-5" />,
    description: "Sell code, scripts, and plugins",
    potentialEarning: "10,000 - 10,00,000/month",
    minEarning: 10000,
    maxEarning: 1000000,
    difficulty: "Hard",
    timeRequired: "2-12 weeks per item",
    link: "https://codecanyon.net/become-an-author",
    features: ["WordPress plugins", "App templates", "Scripts"],
    indianFriendly: true,
  },
  {
    id: "notion-templates",
    name: "Notion Templates",
    category: "Digital Products",
    icon: <FileText className="h-5 w-5" />,
    description: "Create and sell Notion templates",
    potentialEarning: "2,000 - 50,000/month",
    minEarning: 2000,
    maxEarning: 50000,
    difficulty: "Easy",
    timeRequired: "Few hours per template",
    link: "https://www.notion.so/templates",
    features: ["Growing demand", "Easy to create", "Gumroad/own site"],
    indianFriendly: true,
  },
  {
    id: "teachable",
    name: "Teachable",
    category: "Online Courses",
    icon: <GraduationCap className="h-5 w-5" />,
    description: "Host and sell courses on your own platform",
    potentialEarning: "10,000 - 20,00,000/month",
    minEarning: 10000,
    maxEarning: 2000000,
    difficulty: "Hard",
    timeRequired: "1-3 months setup",
    link: "https://teachable.com",
    features: ["Own pricing", "Email marketing", "Full control"],
    indianFriendly: true,
  },
]

const earningsData = [
  { month: "Jan", earnings: 45000, sales: 12 },
  { month: "Feb", earnings: 52000, sales: 15 },
  { month: "Mar", earnings: 48000, sales: 13 },
  { month: "Apr", earnings: 61000, sales: 18 },
  { month: "May", earnings: 75000, sales: 22 },
  { month: "Jun", earnings: 82000, sales: 25 },
  { month: "Jul", earnings: 95000, sales: 30 },
  { month: "Aug", earnings: 88000, sales: 28 },
  { month: "Sep", earnings: 102000, sales: 35 },
  { month: "Oct", earnings: 118000, sales: 40 },
  { month: "Nov", earnings: 135000, sales: 45 },
  { month: "Dec", earnings: 150000, sales: 50 },
]

const categoryData = [
  { name: "E-Books", value: 35, color: "#34d399" },
  { name: "Courses", value: 30, color: "#60a5fa" },
  { name: "Templates", value: 20, color: "#fbbf24" },
  { name: "Apps", value: 10, color: "#f472b6" },
  { name: "Others", value: 5, color: "#a78bfa" },
]

const recentEarnings: Earning[] = [
  { id: "1", platformId: "amazon-kdp", amount: 12500, date: "2024-01-15", type: "royalty" },
  { id: "2", platformId: "udemy", amount: 8750, date: "2024-01-14", type: "sale" },
  { id: "3", platformId: "gumroad", amount: 5200, date: "2024-01-13", type: "sale" },
  { id: "4", platformId: "shutterstock", amount: 3100, date: "2024-01-12", type: "royalty" },
  { id: "5", platformId: "canva", amount: 4500, date: "2024-01-11", type: "royalty" },
]

export default function AutoEarningDashboard() {
  const [activeTab, setActiveTab] = useState<"dashboard" | "opportunities" | "calculator">("dashboard")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [calculatorInputs, setCalculatorInputs] = useState({
    platform: "amazon-kdp",
    unitsPerMonth: 100,
    pricePerUnit: 299,
  })

  const categories = ["All", "E-Books", "Online Courses", "Mobile Apps", "Video Content", "Stock Assets", "Digital Templates", "Design Templates", "Audio/Music", "Code/Scripts", "Digital Products"]

  const filteredPlatforms = platforms.filter((platform) => {
    const matchesSearch = platform.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      platform.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "All" || platform.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const totalEarnings = earningsData.reduce((sum, item) => sum + item.earnings, 0)
  const totalSales = earningsData.reduce((sum, item) => sum + item.sales, 0)
  const avgMonthlyEarning = Math.round(totalEarnings / 12)

  const selectedPlatformForCalc = platforms.find(p => p.id === calculatorInputs.platform)
  const estimatedEarning = calculatorInputs.unitsPerMonth * calculatorInputs.pricePerUnit * 0.7

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy": return "text-green-400 bg-green-400/10"
      case "Medium": return "text-yellow-400 bg-yellow-400/10"
      case "Hard": return "text-red-400 bg-red-400/10"
      default: return "text-muted-foreground bg-muted"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-primary/20 flex items-center justify-center">
                <IndianRupee className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Auto Earning India</h1>
                <p className="text-xs text-muted-foreground">Digital Products Dashboard</p>
              </div>
            </div>
            <nav className="flex items-center gap-1 bg-secondary/50 p-1 rounded-lg">
              <button
                onClick={() => setActiveTab("dashboard")}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  activeTab === "dashboard"
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <BarChart3 className="h-4 w-4 inline-block mr-2" />
                Dashboard
              </button>
              <button
                onClick={() => setActiveTab("opportunities")}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  activeTab === "opportunities"
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Target className="h-4 w-4 inline-block mr-2" />
                Opportunities
              </button>
              <button
                onClick={() => setActiveTab("calculator")}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  activeTab === "calculator"
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Calculator className="h-4 w-4 inline-block mr-2" />
                Calculator
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* Dashboard Tab */}
        {activeTab === "dashboard" && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-card border border-border rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-muted-foreground text-sm">Total Earnings</span>
                  <div className="h-8 w-8 rounded-lg bg-primary/20 flex items-center justify-center">
                    <Wallet className="h-4 w-4 text-primary" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-foreground">
                  {new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(totalEarnings)}
                </p>
                <div className="flex items-center gap-1 mt-2">
                  <ArrowUpRight className="h-3 w-3 text-green-400" />
                  <span className="text-xs text-green-400">+23.5%</span>
                  <span className="text-xs text-muted-foreground">vs last year</span>
                </div>
              </div>

              <div className="bg-card border border-border rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-muted-foreground text-sm">Total Sales</span>
                  <div className="h-8 w-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
                    <TrendingUp className="h-4 w-4 text-blue-400" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-foreground">{totalSales}</p>
                <div className="flex items-center gap-1 mt-2">
                  <ArrowUpRight className="h-3 w-3 text-green-400" />
                  <span className="text-xs text-green-400">+18.2%</span>
                  <span className="text-xs text-muted-foreground">vs last year</span>
                </div>
              </div>

              <div className="bg-card border border-border rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-muted-foreground text-sm">Avg Monthly</span>
                  <div className="h-8 w-8 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                    <Calendar className="h-4 w-4 text-yellow-400" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-foreground">
                  {new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(avgMonthlyEarning)}
                </p>
                <div className="flex items-center gap-1 mt-2">
                  <ArrowUpRight className="h-3 w-3 text-green-400" />
                  <span className="text-xs text-green-400">+12.8%</span>
                  <span className="text-xs text-muted-foreground">growth rate</span>
                </div>
              </div>

              <div className="bg-card border border-border rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-muted-foreground text-sm">Active Platforms</span>
                  <div className="h-8 w-8 rounded-lg bg-pink-500/20 flex items-center justify-center">
                    <Zap className="h-4 w-4 text-pink-400" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-foreground">{platforms.length}</p>
                <div className="flex items-center gap-1 mt-2">
                  <span className="text-xs text-muted-foreground">Available in India</span>
                </div>
              </div>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Earnings Chart */}
              <div className="lg:col-span-2 bg-card border border-border rounded-xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-foreground">Earnings Overview</h3>
                  <span className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded">Last 12 months</span>
                </div>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={earningsData}>
                      <defs>
                        <linearGradient id="colorEarnings" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#34d399" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#34d399" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                      <XAxis dataKey="month" stroke="#666" fontSize={12} />
                      <YAxis stroke="#666" fontSize={12} tickFormatter={(value) => `${value / 1000}k`} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1a1a2e",
                          border: "1px solid #333",
                          borderRadius: "8px",
                          color: "#fff",
                        }}
                        formatter={(value: number) => [
                          new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(value),
                          "Earnings",
                        ]}
                      />
                      <Area
                        type="monotone"
                        dataKey="earnings"
                        stroke="#34d399"
                        strokeWidth={2}
                        fillOpacity={1}
                        fill="url(#colorEarnings)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Category Distribution */}
              <div className="bg-card border border-border rounded-xl p-5">
                <h3 className="font-semibold text-foreground mb-4">Earnings by Category</h3>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={70}
                        paddingAngle={4}
                        dataKey="value"
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1a1a2e",
                          border: "1px solid #333",
                          borderRadius: "8px",
                          color: "#fff",
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  {categoryData.map((item) => (
                    <div key={item.name} className="flex items-center gap-2">
                      <div className="h-2 w-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-xs text-muted-foreground">{item.name}</span>
                      <span className="text-xs font-medium text-foreground ml-auto">{item.value}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recent Earnings */}
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="font-semibold text-foreground mb-4">Recent Earnings</h3>
              <div className="space-y-3">
                {recentEarnings.map((earning) => {
                  const platform = platforms.find((p) => p.id === earning.platformId)
                  return (
                    <div
                      key={earning.id}
                      className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center">
                          {platform?.icon}
                        </div>
                        <div>
                          <p className="font-medium text-foreground text-sm">{platform?.name}</p>
                          <p className="text-xs text-muted-foreground capitalize">{earning.type}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-green-400">
                          +{new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(earning.amount)}
                        </p>
                        <p className="text-xs text-muted-foreground">{earning.date}</p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        )}

        {/* Opportunities Tab */}
        {activeTab === "opportunities" && (
          <div className="space-y-6">
            {/* Search and Filter */}
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search platforms..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-card border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="bg-card border border-border rounded-lg px-3 py-2.5 text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Platforms Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredPlatforms.map((platform) => (
                <div
                  key={platform.id}
                  className="bg-card border border-border rounded-xl p-5 hover:border-primary/50 transition-all group"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center text-primary">
                        {platform.icon}
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">{platform.name}</h3>
                        <p className="text-xs text-muted-foreground">{platform.category}</p>
                      </div>
                    </div>
                    {platform.indianFriendly && (
                      <span className="text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded-full">India</span>
                    )}
                  </div>

                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{platform.description}</p>

                  <div className="space-y-3 mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">Potential Earning</span>
                      <span className="text-sm font-semibold text-primary">{platform.potentialEarning}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">Difficulty</span>
                      <span className={`text-xs px-2 py-0.5 rounded ${getDifficultyColor(platform.difficulty)}`}>
                        {platform.difficulty}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">Time Required</span>
                      <span className="text-xs text-foreground">{platform.timeRequired}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-4">
                    {platform.features.map((feature, idx) => (
                      <span key={idx} className="text-xs bg-secondary px-2 py-1 rounded text-muted-foreground">
                        {feature}
                      </span>
                    ))}
                  </div>

                  <a
                    href={platform.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-center gap-2 bg-primary/10 text-primary py-2 rounded-lg text-sm font-medium hover:bg-primary hover:text-primary-foreground transition-all"
                  >
                    Visit Platform
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Calculator Tab */}
        {activeTab === "calculator" && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-card border border-border rounded-xl p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Calculator className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-foreground">Income Calculator</h2>
                  <p className="text-sm text-muted-foreground">Estimate your potential earnings</p>
                </div>
              </div>

              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Select Platform</label>
                  <select
                    value={calculatorInputs.platform}
                    onChange={(e) => setCalculatorInputs({ ...calculatorInputs, platform: e.target.value })}
                    className="w-full bg-secondary border border-border rounded-lg px-4 py-3 text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    {platforms.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.category})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Units/Sales per Month
                  </label>
                  <input
                    type="number"
                    value={calculatorInputs.unitsPerMonth}
                    onChange={(e) =>
                      setCalculatorInputs({ ...calculatorInputs, unitsPerMonth: parseInt(e.target.value) || 0 })
                    }
                    className="w-full bg-secondary border border-border rounded-lg px-4 py-3 text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="100"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Price per Unit (INR)</label>
                  <input
                    type="number"
                    value={calculatorInputs.pricePerUnit}
                    onChange={(e) =>
                      setCalculatorInputs({ ...calculatorInputs, pricePerUnit: parseInt(e.target.value) || 0 })
                    }
                    className="w-full bg-secondary border border-border rounded-lg px-4 py-3 text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="299"
                  />
                </div>

                <div className="bg-primary/10 rounded-xl p-5 mt-6">
                  <p className="text-sm text-muted-foreground mb-2">Estimated Monthly Earning (70% royalty)</p>
                  <p className="text-3xl font-bold text-primary">
                    {new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(estimatedEarning)}
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Based on {selectedPlatformForCalc?.name} average royalty rates
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="bg-secondary/50 rounded-lg p-4">
                    <p className="text-xs text-muted-foreground mb-1">Yearly Projection</p>
                    <p className="text-lg font-semibold text-foreground">
                      {new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(estimatedEarning * 12)}
                    </p>
                  </div>
                  <div className="bg-secondary/50 rounded-lg p-4">
                    <p className="text-xs text-muted-foreground mb-1">Platform Range</p>
                    <p className="text-lg font-semibold text-foreground">{selectedPlatformForCalc?.potentialEarning}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
